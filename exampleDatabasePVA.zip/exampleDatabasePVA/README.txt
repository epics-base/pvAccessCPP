to build:

in configure:

copy ExampleRELEASE.local to RELEASE.local
change EPICS_BASE and EPICS4_DIR

at top:

make
